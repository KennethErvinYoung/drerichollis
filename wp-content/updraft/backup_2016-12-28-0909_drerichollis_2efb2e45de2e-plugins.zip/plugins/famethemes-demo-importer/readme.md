### Support Themes and Plugins
- [x] Screenr
- [x] Screenr Plus
- [x] Boston
- [x] Boston Pro
- [x] OnePress
- [x] OnePress Plus
- [ ] Coupon WP
- [ ] Techone
- [ ] Codilight
- [ ] Inspirin
- [ ] Amzola
- [ ] Wentasi
- [ ] Laverde
- [ ] Bloom
- [ ] Beandot
- [ ] LightBog





