<?php exit(0); ?>
{"user_id":1,"user_login":"drerichollis_admin","user_remoteaddr":"127.0.0.1","user_hostname":"localhost","user_lastlogin":"2017-01-03 13:02:49"}
{"user_id":1,"user_login":"drerichollis_admin","user_remoteaddr":"127.0.0.1","user_hostname":"localhost","user_lastlogin":"2017-01-13 12:14:43"}
{"user_id":1,"user_login":"drerichollis_admin","user_remoteaddr":"127.0.0.1","user_hostname":"localhost","user_lastlogin":"2017-01-13 12:28:06"}
{"user_id":1,"user_login":"drerichollis_admin","user_remoteaddr":"127.0.0.1","user_hostname":"localhost","user_lastlogin":"2017-01-13 14:16:06"}
{"user_id":1,"user_login":"drerichollis_admin","user_remoteaddr":"127.0.0.1","user_hostname":"localhost","user_lastlogin":"2017-01-13 21:24:13"}
{"user_id":1,"user_login":"drerichollis_admin","user_remoteaddr":"127.0.0.1","user_hostname":"localhost","user_lastlogin":"2017-01-15 17:13:09"}
{"user_id":1,"user_login":"drerichollis_admin","user_remoteaddr":"127.0.0.1","user_hostname":"localhost","user_lastlogin":"2017-01-16 17:26:28"}
