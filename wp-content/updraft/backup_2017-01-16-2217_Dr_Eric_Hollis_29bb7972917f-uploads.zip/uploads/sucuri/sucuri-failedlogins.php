<?php exit(0); ?>
{"user_login":"kennethervinyoung","user_password":"","attempt_time":1484327604,"remote_addr":"127.0.0.1","user_agent":"Mozilla\/5.0 (Macintosh; Intel Mac OS X 10_12_2) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/55.0.2883.95 Safari\/537.36"}
