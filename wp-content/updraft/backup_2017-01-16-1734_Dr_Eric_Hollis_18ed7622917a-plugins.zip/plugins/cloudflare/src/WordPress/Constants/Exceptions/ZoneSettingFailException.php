<?php

namespace CF\WordPress\Constants\Exceptions;

class ZoneSettingFailException extends \Exception
{
    protected $message = 'Oops, something went wrong, please try again in a few minutes';
}
