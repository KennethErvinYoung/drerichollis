=== Plugin Name ===
Contributors: famethemes
Tags: onepage
Requires at least: 4.6
Tested up to: 4.6
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Screenr Plus Plugin, Copyright 2016 FameThemes
Screenr Plus is distributed under the terms of the GNU GPL

== Description ==

The Screenr Plus plugin adds powerful premium features to Screenr

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Go to Customizer to see addition sections + feature settings.

== Frequently Asked Questions ==


== Changelog ==
= 1.0.5 =
* WP 4.7 compatible.
* Update Custom section + JS.
* Fix visual editor show textarea instead when use disable visual editor.
* Fix a bug duplicate content on repeater editor

= 1.0.4 =
* Fix a bug duplicate content on repeater editor.
* Visual editor show textarea instead when use disable visual editor.

= 1.0.3 =
* Fix bug customize editor.

= 1.0.2 =
* Add Gallery section.

= 1.0.1 =
* Remove upsell section.
* Sync with Screenr theme

= 1.0.0 =
* Initial release
